using System;
using System.Collections.Generic;
using System.Text;

namespace Compiler.Dynamic.Text
{
    internal class ReferenceInCode
    {
        static readonly string[] _SystemSpecRefs = 
        {
            "System.Configuration",
            "System.Configuration.Install",
            "System.Data",
            "System.Data.DataSetExtensions",
            "System.Data.SqlClient",
            "System.Data.SqlXml",
            "System.Deployment",
            "System.Design",
            "Sysemt.DirecoryServices",
            "System.DirectoryServices.Protocols",
            "System.Drawing",
            "System.Drawing.Design",
            "System.EnterpriseServices",
            "System.Management",
            "System.Messaging",
            "System.Runtime.Remoting",
            "System.Runtime.Serialization.Formatters.Soap",
            "System.Security",
            "System.ServiceProcess",
            "System.Transactions",
            "System.Web",
            "System.Web.Mobile",
            "System.Web.RegularExpressions",
            "System.Web.Services",
            "System.Windows.Forms",
            "System.Xml",
            "System.Xml.Linq",
        };

        static private string GetSystemReferenceDllName(string namespaceText)
        {
            foreach (string sysSpecRef in _SystemSpecRefs)
            {
                if (namespaceText.IndexOf(sysSpecRef) == 0)
                {
                    return sysSpecRef + ".dll";
                }
            }

            return "System.dll";
        }

        static public List<string> GetNameSpacesInSourceCode(string code)
        {
            return Regx.GetMatchStrings(code, @"using\s+(.+?)\s*;", false);
        }

        static public string GetDefaultReferenceDllName(string namespaceText)
        {
            namespaceText = namespaceText.Trim();

            if (namespaceText.IndexOf("System") == 0)
            {
                return GetSystemReferenceDllName(namespaceText);
            }
            else
            {
                return namespaceText + ".dll";
            }

        }
    }
}
