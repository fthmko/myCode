using System;
using System.Collections.Generic;
using System.Text;

namespace MyInterface
{
    public interface IHelloWorld
    {
        string Say();
    }
}
