using System;
using System.Collections.Generic;
using System.Text;
using Compiler.Dynamic;
using MyInterface;

namespace DynamiclyCompiler
{
    class GetInstance
    {
        static CSharpProvider _SharpProvider;
        static public CSharpProvider SharpProvider
        {
            get
            {
                if (_SharpProvider == null)
                {
                    _SharpProvider = new CSharpProvider();
                }

                _SharpProvider.AssemblyFileName = "HelloWorld.dll";
                _SharpProvider.RemoveAssemblyFile = true;
                return _SharpProvider;
            }
        }

        static public IHelloWorld GetHelloWorldInterface(string code)
        {
            return (IHelloWorld)SharpProvider.CreateInstance(code, "MyInterface.IHelloWorld");
        }

        static public IHelloWorld GetHelloWorldInterfaceFromFile(string fileName)
        {
            return (IHelloWorld)SharpProvider.CreateInstanceFromFile(fileName, "MyInterface.IHelloWorld");
        }

        static public void Unload()
        {
            SharpProvider.Dispose();
            _SharpProvider = null;
        }
    }
}
