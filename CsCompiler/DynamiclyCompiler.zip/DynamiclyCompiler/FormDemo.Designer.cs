namespace DynamiclyCompiler
{
    partial class FormDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExcute = new System.Windows.Forms.Button();
            this.richTextBoxCode = new System.Windows.Forms.RichTextBox();
            this.buttonExcuteFile = new System.Windows.Forms.Button();
            this.openFileDialogSourceCode = new System.Windows.Forms.OpenFileDialog();
            this.buttonUnload = new System.Windows.Forms.Button();
            this.checkBoxIncludeDebugInfo = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // buttonExcute
            // 
            this.buttonExcute.Location = new System.Drawing.Point(13, 13);
            this.buttonExcute.Name = "buttonExcute";
            this.buttonExcute.Size = new System.Drawing.Size(75, 23);
            this.buttonExcute.TabIndex = 0;
            this.buttonExcute.Text = "Excute";
            this.buttonExcute.UseVisualStyleBackColor = true;
            this.buttonExcute.Click += new System.EventHandler(this.buttonExcute_Click);
            // 
            // richTextBoxCode
            // 
            this.richTextBoxCode.Location = new System.Drawing.Point(13, 72);
            this.richTextBoxCode.Name = "richTextBoxCode";
            this.richTextBoxCode.Size = new System.Drawing.Size(577, 281);
            this.richTextBoxCode.TabIndex = 1;
            this.richTextBoxCode.Text = "";
            // 
            // buttonExcuteFile
            // 
            this.buttonExcuteFile.Location = new System.Drawing.Point(108, 12);
            this.buttonExcuteFile.Name = "buttonExcuteFile";
            this.buttonExcuteFile.Size = new System.Drawing.Size(75, 23);
            this.buttonExcuteFile.TabIndex = 2;
            this.buttonExcuteFile.Text = "Excute File";
            this.buttonExcuteFile.UseVisualStyleBackColor = true;
            this.buttonExcuteFile.Click += new System.EventHandler(this.buttonExcuteFile_Click);
            // 
            // openFileDialogSourceCode
            // 
            this.openFileDialogSourceCode.DefaultExt = "*.cs";
            this.openFileDialogSourceCode.FileName = "*.cs";
            this.openFileDialogSourceCode.Filter = "c# file|*.cs";
            // 
            // buttonUnload
            // 
            this.buttonUnload.Location = new System.Drawing.Point(201, 12);
            this.buttonUnload.Name = "buttonUnload";
            this.buttonUnload.Size = new System.Drawing.Size(75, 23);
            this.buttonUnload.TabIndex = 3;
            this.buttonUnload.Text = "Unload";
            this.buttonUnload.UseVisualStyleBackColor = true;
            this.buttonUnload.Click += new System.EventHandler(this.buttonUnload_Click);
            // 
            // checkBoxIncludeDebugInfo
            // 
            this.checkBoxIncludeDebugInfo.AutoSize = true;
            this.checkBoxIncludeDebugInfo.Checked = true;
            this.checkBoxIncludeDebugInfo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxIncludeDebugInfo.Location = new System.Drawing.Point(14, 49);
            this.checkBoxIncludeDebugInfo.Name = "checkBoxIncludeDebugInfo";
            this.checkBoxIncludeDebugInfo.Size = new System.Drawing.Size(111, 17);
            this.checkBoxIncludeDebugInfo.TabIndex = 4;
            this.checkBoxIncludeDebugInfo.Text = "IncludeDebugInfo";
            this.checkBoxIncludeDebugInfo.UseVisualStyleBackColor = true;
            // 
            // FormDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 386);
            this.Controls.Add(this.checkBoxIncludeDebugInfo);
            this.Controls.Add(this.buttonUnload);
            this.Controls.Add(this.buttonExcuteFile);
            this.Controls.Add(this.richTextBoxCode);
            this.Controls.Add(this.buttonExcute);
            this.Name = "FormDemo";
            this.Text = "Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExcute;
        private System.Windows.Forms.RichTextBox richTextBoxCode;
        private System.Windows.Forms.Button buttonExcuteFile;
        private System.Windows.Forms.OpenFileDialog openFileDialogSourceCode;
        private System.Windows.Forms.Button buttonUnload;
        private System.Windows.Forms.CheckBox checkBoxIncludeDebugInfo;
    }
}

