using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MyInterface;

namespace DynamiclyCompiler
{
    public partial class FormDemo : Form
    {
        public FormDemo()
        {
            InitializeComponent();
        }

        private void buttonExcute_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
                stopWatch.Start();

                GetInstance.SharpProvider.CompilerParameters.IncludeDebugInformation =
                    checkBoxIncludeDebugInfo.Checked;

                IHelloWorld helloWorld = GetInstance.GetHelloWorldInterface(richTextBoxCode.Text);

                stopWatch.Stop();

                this.Text = helloWorld.Say() + " " + stopWatch.ElapsedMilliseconds + "ms";
            }
            catch (Compiler.Dynamic.CompilerException ce)
            {
                MessageBox.Show(ce.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (System.IO.FileStream fs = new System.IO.FileStream("HelloWorld.cs", System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(fs);

                richTextBoxCode.Text = sr.ReadToEnd();
            }
        }

        private void buttonExcuteFile_Click(object sender, EventArgs e)
        {
            if (openFileDialogSourceCode.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
                    stopWatch.Start();

                    GetInstance.SharpProvider.CompilerParameters.IncludeDebugInformation =
                        checkBoxIncludeDebugInfo.Checked;

                    IHelloWorld helloWorld = GetInstance.GetHelloWorldInterfaceFromFile(openFileDialogSourceCode.FileName);

                    stopWatch.Stop();

                    this.Text = helloWorld.Say() + " " + stopWatch.ElapsedMilliseconds + "ms";
                }
                catch (Compiler.Dynamic.CompilerException ce)
                {
                    MessageBox.Show(ce.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonUnload_Click(object sender, EventArgs e)
        {
            GetInstance.Unload();
        }
    }
}