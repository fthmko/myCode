using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace Compiler.Dynamic.Text
{
    internal class File
    {
        static public String ReadFileToString(String fileName, Encoding encoding)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs, encoding);
                return sr.ReadToEnd();
            }
        }
    }
}
